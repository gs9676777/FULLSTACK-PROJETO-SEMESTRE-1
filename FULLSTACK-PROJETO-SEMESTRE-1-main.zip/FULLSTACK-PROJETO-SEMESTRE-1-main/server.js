const express = require('express');
const path = require('path');

const app = express();
const PORT = 80; 


app.use(express.static(path.join(__dirname, 'public')));


app.get('/index.html', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'Home.html'));
});


app.listen(PORT, '0.0.0.0', () => {
  console.log(`Servidor rodando! Acesse: http://<seu-ip>/Home.html`);
});
